<?xml version='1.0'?>
<Project Type="Project" LVVersion="8208002">
	<Item Name="My Computer" Type="My Computer">
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="Vaunix LMS.lvlib" Type="Library" URL="Vaunix LMS.lvlib">
			<Item Name="Private" Type="Folder"/>
			<Item Name="Public" Type="Folder">
				<Item Name="Configure" Type="Folder">
					<Item Name="Close Device.vi" Type="VI" URL="Public/Configure/Close Device.vi"/>
					<Item Name="Decode Device Status.vi" Type="VI" URL="Public/Configure/Decode Device Status.vi"/>
					<Item Name="Get Device Info.vi" Type="VI" URL="Public/Configure/Get Device Info.vi"/>
					<Item Name="Get Device Status.vi" Type="VI" URL="Public/Configure/Get Device Status.vi"/>
					<Item Name="Get Model Name.vi" Type="VI" URL="Public/Configure/Get Model Name.vi"/>
					<Item Name="Get Num Devices.vi" Type="VI" URL="Public/Configure/Get Num Devices.vi"/>
					<Item Name="Get Serial Number.vi" Type="VI" URL="Public/Configure/Get Serial Number.vi"/>
					<Item Name="Init Device.vi" Type="VI" URL="Public/Configure/Init Device.vi"/>
					<Item Name="Configure.mnu" Type="Document" URL="Public/Configure/Configure.mnu"/>
				</Item>
				<Item Name="Get" Type="Folder">
					<Item Name="Get End Frequency.vi" Type="VI" URL="Public/Get/Get End Frequency.vi"/>
					<Item Name="Get Frequency.vi" Type="VI" URL="Public/Get/Get Frequency.vi"/>
					<Item Name="Get Has Fast Pulse Mode.vi" Type="VI" URL="Public/Get/Get Has Fast Pulse Mode.vi"/>
					<Item Name="Get Max Frequency.vi" Type="VI" URL="Public/Get/Get Max Frequency.vi"/>
					<Item Name="Get Min Frequency.vi" Type="VI" URL="Public/Get/Get Min Frequency.vi"/>
					<Item Name="Get Max Power.vi" Type="VI" URL="Public/Get/Get Max Power.vi"/>
					<Item Name="Get Min Power.vi" Type="VI" URL="Public/Get/Get Min Power.vi"/>
					<Item Name="Get Power Level.vi" Type="VI" URL="Public/Get/Get Power Level.vi"/>
					<Item Name="Get Pulse Mode.vi" Type="VI" URL="Public/Get/Get Pulse Mode.vi"/>
					<Item Name="Get Pulse Off Time.vi" Type="VI" URL="Public/Get/Get Pulse Off Time.vi"/>
					<Item Name="Get Pulse On Time.vi" Type="VI" URL="Public/Get/Get Pulse On Time.vi"/>
					<Item Name="Get RF On.vi" Type="VI" URL="Public/Get/Get RF On.vi"/>
					<Item Name="Get Start Frequency.vi" Type="VI" URL="Public/Get/Get Start Frequency.vi"/>
					<Item Name="Get Sweep Time.vi" Type="VI" URL="Public/Get/Get Sweep Time.vi"/>
					<Item Name="Get Use Internal Pulse Mode.vi" Type="VI" URL="Public/Get/Get Use Internal Pulse Mode.vi"/>
					<Item Name="Get Use Internal Reference.vi" Type="VI" URL="Public/Get/Get Use Internal Reference.vi"/>
					<Item Name="Get.mnu" Type="Document" URL="Public/Get/Get.mnu"/>
				</Item>
				<Item Name="Set" Type="Folder">
					<Item Name="Enable Internal Pulse Mod.vi" Type="VI" URL="Public/Set/Enable Internal Pulse Mod.vi"/>
					<Item Name="Set Start Frequency.vi" Type="VI" URL="Public/Set/Set Start Frequency.vi"/>
					<Item Name="Set End Frequency.vi" Type="VI" URL="Public/Set/Set End Frequency.vi"/>
					<Item Name="Set Fast Pulsed Output.vi" Type="VI" URL="Public/Set/Set Fast Pulsed Output.vi"/>
					<Item Name="Set Frequency.vi" Type="VI" URL="Public/Set/Set Frequency.vi"/>
					<Item Name="Set Power Level.vi" Type="VI" URL="Public/Set/Set Power Level.vi"/>
					<Item Name="Set Pulse Off Time.vi" Type="VI" URL="Public/Set/Set Pulse Off Time.vi"/>
					<Item Name="Set Pulse On Time.vi" Type="VI" URL="Public/Set/Set Pulse On Time.vi"/>
					<Item Name="Set RF On.vi" Type="VI" URL="Public/Set/Set RF On.vi"/>
					<Item Name="Set Sweep Direction.vi" Type="VI" URL="Public/Set/Set Sweep Direction.vi"/>
					<Item Name="Set Sweep Mode.vi" Type="VI" URL="Public/Set/Set Sweep Mode.vi"/>
					<Item Name="Set Sweep Time.vi" Type="VI" URL="Public/Set/Set Sweep Time.vi"/>
					<Item Name="Set Sweep Type.vi" Type="VI" URL="Public/Set/Set Sweep Type.vi"/>
					<Item Name="Set Use External Pulse Mod.vi" Type="VI" URL="Public/Set/Set Use External Pulse Mod.vi"/>
					<Item Name="Set Use Internal Reference.vi" Type="VI" URL="Public/Set/Set Use Internal Reference.vi"/>
					<Item Name="Start Sweep.vi" Type="VI" URL="Public/Set/Start Sweep.vi"/>
					<Item Name="Set.mnu" Type="Document" URL="Public/Set/Set.mnu"/>
				</Item>
				<Item Name="Utility" Type="Folder">
					<Item Name="Error Handler.vi" Type="VI" URL="Public/Utility/Error Handler.vi"/>
					<Item Name="Get DLL Version.vi" Type="VI" URL="Public/Utility/Get DLL Version.vi"/>
					<Item Name="Save Settings.vi" Type="VI" URL="Public/Utility/Save Settings.vi"/>
					<Item Name="Set Test Mode.vi" Type="VI" URL="Public/Utility/Set Test Mode.vi"/>
					<Item Name="Utility.mnu" Type="Document" URL="Public/Utility/Utility.mnu"/>
				</Item>
				<Item Name="Dir.mnu" Type="Document" URL="Public/Dir.mnu"/>
				<Item Name="Example.vi" Type="VI" URL="Public/Example.vi"/>
				<Item Name="VI Tree.vi" Type="VI" URL="Public/VI Tree.vi"/>
			</Item>
			<Item Name="Lab Brick LMS API Manual.pdf" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Lab Brick LMS API Manual.pdf"/>
			<Item Name="Vaunix LMS Readme.pdf" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Vaunix LMS Readme.pdf"/>
			<Item Name="vnx_fmsynth.dll" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/vnx_fmsynth.dll"/>
		</Item>
		<Item Name="Dependencies" Type="Dependencies">
			<Item Name="vi.lib" Type="Folder">
				<Item Name="Clear Errors.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/error.llb/Clear Errors.vi"/>
			</Item>
		</Item>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
