<?xml version='1.0'?>
<Library LVVersion="8208002">
	<Property Name="Instrument Driver" Type="Str">True</Property>
	<Property Name="NI.Lib.DefaultMenu" Type="Str">dir.mnu</Property>
	<Property Name="NI.Lib.Description" Type="Str">LabVIEW Plug and Play instrument driver for
Vaunix LMS RF Signal Generator</Property>
	<Property Name="NI.Lib.Icon" Type="Bin">###!!A!!!!Y!%%!$#GFN97&gt;F)(2Z='5!!""!!QNJ&lt;7&amp;H:3"E:8"U;!!%!!5!%E"!!!(`````!!)&amp;;7VB:W5!%E"!!!(`````!!)%&lt;7&amp;T;Q!!"!!(!"2!1!!"`````Q!&amp;"G.P&lt;'^S=Q!!#E!#"'RF:H1!!!B!!A.U&lt;X!!#E!#"8*J:WBU!!R!!A:C&lt;X2U&lt;WU!!"B!5!!%!!=!#!!*!!I*5G6D&gt;'&amp;O:WRF!$A!]1!!!!!!!!!"$7FN97&gt;F:'&amp;U93ZD&gt;'Q!)E"1!!9!!!!"!!-!"!!'!!M+37VB:W5A:'&amp;U91!!#A"1!!)!$!!-!!%!$1!!!!!!!!!)!!!%!0````````````````````````````````````````````&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P``^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W```W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;```&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P``^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W```W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;```&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P&lt;W^P``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$```````````````````````````````````````````]!!!#!``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````]!!!%!!0```Q$``]Q!``_:!0``:A$``T-!``]!!0`-`Q$`T-Q!`]S:!0`-:A$`T$-!`]Q!!0_:`Q$`G=Q!`ZG:!0_::A$`G4-!`ZE!!0^G`Q$`:MQ!`W;:!0^G:A$`:D-!`W9!!0]T`Q$`-]Q!`T/:!0]T:A$`-T-!`T-!!0]!`Q$`!-Q!`Q#:!0]!:A$`!$-!`Q!!!-T``Q$-`]Q!T0_:!-T`:A$-`T-!T0]!!-T-`Q$-T-Q!T-S:!-T-:A$-T$-!T-Q!!-S:`Q$-G=Q!T*G:!-S::A$-G4-!T*E!!-RG`Q$-:MQ!T';:!-RG:A$-:D-!T'9!!-QT`Q$--]Q!T$/:!-QT:A$--T-!T$-!!-Q!`Q$-!-Q!T!#:!-Q!:A$-!$-!T!!!!*H``Q#:`]Q!G@_:!*H`:A#:`T-!G@]!!*H-`Q#:T-Q!G=S:!*H-:A#:T$-!G=Q!!*G:`Q#:G=Q!G:G:!*G::A#:G4-!G:E!!*FG`Q#::MQ!G7;:!*FG:A#::D-!G79!!*ET`Q#:-]Q!G4/:!*ET:A#:-T-!G4-!!*E!`Q#:!-Q!G1#:!*E!:A#:!$-!G1!!!'&lt;``Q"G`]Q!:P_:!'&lt;`:A"G`T-!:P]!!'&lt;-`Q"GT-Q!:MS:!'&lt;-:A"GT$-!:MQ!!';:`Q"GG=Q!:JG:!';::A"GG4-!:JE!!':G`Q"G:MQ!:G;:!':G:A"G:D-!:G9!!'9T`Q"G-]Q!:D/:!'9T:A"G-T-!:D-!!'9!`Q"G!-Q!:A#:!'9!:A"G!$-!:A!!!$0``Q!T`]Q!-`_:!$0`:A!T`T-!-`]!!$0-`Q!TT-Q!-]S:!$0-:A!TT$-!-]Q!!$/:`Q!TG=Q!-ZG:!$/::A!TG4-!-ZE!!$.G`Q!T:MQ!-W;:!$.G:A!T:D-!-W9!!$-T`Q!T-]Q!-T/:!$-T:A!T-T-!-T-!!$-!`Q!T!-Q!-Q#:!$-!:A!T!$-!-Q!!!!$``Q!!`]Q!!0_:!!$`:A!!`T-!!0]!!!$-`Q!!T-Q!!-S:!!$-:A!!T$-!!-Q!!!#:`Q!!G=Q!!*G:!!#::A!!G4-!!*E!!!"G`Q!!:MQ!!';:!!"G:A!!:D-!!'9!!!!T`Q!!-]Q!!$/:!!!T:A!!-T-!!$-!!!!!`Q!!!-Q!!!#:!!!!:A!!!$-!\A!!!.U!!!#\!!!!KA!!!)A!!!"X!!!!61!!!%1!!!!C!!!!%1!!!!$O!!!!X1!!!,M!!!#K!!!!C!!!!(=!!!"6!!!!2!!!!#)!!!!2!!!!!/Y!!!$&gt;!!!!OQ!!!+I!!!#)!!!!&gt;Q!!!&amp;5!!!"%!!!!)A!!!"%!\O\O!.X&gt;X1#\O\M!KKKK!)C)C!"X&gt;X=!6666!%2%2!!C)C)!%2%2!!!!!!!!!!!!)!!A!!!!!!!!!!%!!!#!`````Y!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!@````]!!!#!``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````]!!!!#!0```Q!!!!!!!!!!!#!!)!!!!!!</Property>
	<Property Name="NI.Lib.Version" Type="Str">1.0.0.0</Property>
	<Item Name="Private" Type="Folder">
		<Property Name="NI.LibItem.Scope" Type="Int">2</Property>
	</Item>
	<Item Name="Public" Type="Folder">
		<Property Name="NI.LibItem.Scope" Type="Int">1</Property>
		<Item Name="Configure" Type="Folder">
			<Item Name="Get Device Status.vi" Type="VI" URL="Public/Configure/Get Device Status.vi"/>
			<Item Name="Get Model Name.vi" Type="VI" URL="Public/Configure/Get Model Name.vi"/>
			<Item Name="Get Num Devices.vi" Type="VI" URL="Public/Configure/Get Num Devices.vi"/>
			<Item Name="Get Serial Number.vi" Type="VI" URL="Public/Configure/Get Serial Number.vi"/>
			<Item Name="Init Device.vi" Type="VI" URL="Public/Configure/Init Device.vi"/>
			<Item Name="Close Device.vi" Type="VI" URL="Public/Configure/Close Device.vi"/>
			<Item Name="Decode Device Status.vi" Type="VI" URL="Public/Configure/Decode Device Status.vi"/>
			<Item Name="Get Device Info.vi" Type="VI" URL="Public/Configure/Get Device Info.vi"/>
			<Item Name="Configure.mnu" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Public/Configure/Configure.mnu"/>
		</Item>
		<Item Name="Get" Type="Folder">
			<Item Name="Get End Frequency.vi" Type="VI" URL="Public/Get/Get End Frequency.vi"/>
			<Item Name="Get Frequency.vi" Type="VI" URL="Public/Get/Get Frequency.vi"/>
			<Item Name="Get Has Fast Pulse Mode.vi" Type="VI" URL="Public/Get/Get Has Fast Pulse Mode.vi"/>
			<Item Name="Get Max Frequency.vi" Type="VI" URL="Public/Get/Get Max Frequency.vi"/>
			<Item Name="Get Max Power.vi" Type="VI" URL="Public/Get/Get Max Power.vi"/>
			<Item Name="Get Min Frequency.vi" Type="VI" URL="Public/Get/Get Min Frequency.vi"/>
			<Item Name="Get Min Power.vi" Type="VI" URL="Public/Get/Get Min Power.vi"/>
			<Item Name="Get Power Level.vi" Type="VI" URL="Public/Get/Get Power Level.vi"/>
			<Item Name="Get Pulse Mode.vi" Type="VI" URL="Public/Get/Get Pulse Mode.vi"/>
			<Item Name="Get Pulse Off Time.vi" Type="VI" URL="Public/Get/Get Pulse Off Time.vi"/>
			<Item Name="Get Pulse On Time.vi" Type="VI" URL="Public/Get/Get Pulse On Time.vi"/>
			<Item Name="Get RF On.vi" Type="VI" URL="Public/Get/Get RF On.vi"/>
			<Item Name="Get Start Frequency.vi" Type="VI" URL="Public/Get/Get Start Frequency.vi"/>
			<Item Name="Get Sweep Time.vi" Type="VI" URL="Public/Get/Get Sweep Time.vi"/>
			<Item Name="Get Use Internal Pulse Mod.vi" Type="VI" URL="Public/Get/Get Use Internal Pulse Mod.vi"/>
			<Item Name="Get Use Internal Reference.vi" Type="VI" URL="Public/Get/Get Use Internal Reference.vi"/>
			<Item Name="Get.mnu" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Public/Get/Get.mnu"/>
		</Item>
		<Item Name="Set" Type="Folder">
			<Item Name="Enable Internal Pulse Mod.vi" Type="VI" URL="Public/Set/Enable Internal Pulse Mod.vi"/>
			<Item Name="Set End Frequency.vi" Type="VI" URL="Public/Set/Set End Frequency.vi"/>
			<Item Name="Set Fast Pulsed Output.vi" Type="VI" URL="Public/Set/Set Fast Pulsed Output.vi"/>
			<Item Name="Set Frequency.vi" Type="VI" URL="Public/Set/Set Frequency.vi"/>
			<Item Name="Set Power Level.vi" Type="VI" URL="Public/Set/Set Power Level.vi"/>
			<Item Name="Set Pulse Off Time.vi" Type="VI" URL="Public/Set/Set Pulse Off Time.vi"/>
			<Item Name="Set Pulse On Time.vi" Type="VI" URL="Public/Set/Set Pulse On Time.vi"/>
			<Item Name="Set RF On.vi" Type="VI" URL="Public/Set/Set RF On.vi"/>
			<Item Name="Set Start Frequency.vi" Type="VI" URL="Public/Set/Set Start Frequency.vi"/>
			<Item Name="Set Sweep Direction.vi" Type="VI" URL="Public/Set/Set Sweep Direction.vi"/>
			<Item Name="Set Sweep Mode.vi" Type="VI" URL="Public/Set/Set Sweep Mode.vi"/>
			<Item Name="Set Sweep Time.vi" Type="VI" URL="Public/Set/Set Sweep Time.vi"/>
			<Item Name="Set Sweep Type.vi" Type="VI" URL="Public/Set/Set Sweep Type.vi"/>
			<Item Name="Set Use External Pulse Mod.vi" Type="VI" URL="Public/Set/Set Use External Pulse Mod.vi"/>
			<Item Name="Set Use Internal Reference.vi" Type="VI" URL="Public/Set/Set Use Internal Reference.vi"/>
			<Item Name="Start Sweep.vi" Type="VI" URL="Public/Set/Start Sweep.vi"/>
			<Item Name="Set.mnu" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Public/Set/Set.mnu"/>
		</Item>
		<Item Name="Utility" Type="Folder">
			<Item Name="Error Handler.vi" Type="VI" URL="Public/Utility/Error Handler.vi"/>
			<Item Name="Get DLL Version.vi" Type="VI" URL="Public/Utility/Get DLL Version.vi"/>
			<Item Name="Save Settings.vi" Type="VI" URL="Public/Utility/Save Settings.vi"/>
			<Item Name="Set Test Mode.vi" Type="VI" URL="Public/Utility/Set Test Mode.vi"/>
			<Item Name="Utility.mnu" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Public/Utility/Utility.mnu"/>
		</Item>
		<Item Name="dir.mnu" Type="Document" URL="Public/dir.mnu"/>
		<Item Name="VI Tree.vi" Type="VI" URL="Public/VI Tree.vi"/>
		<Item Name="Example.vi" Type="VI" URL="Public/Example.vi"/>
	</Item>
	<Item Name="Lab Brick LMS API Manual.pdf" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Lab Brick LMS API Manual.pdf"/>
	<Item Name="Vaunix LMS Readme.pdf" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/Vaunix LMS Readme.pdf"/>
	<Item Name="vnx_fmsynth.dll" Type="Document" URL="/&lt;instrlib&gt;/Vaunix LMS/vnx_fmsynth.dll"/>
</Library>
