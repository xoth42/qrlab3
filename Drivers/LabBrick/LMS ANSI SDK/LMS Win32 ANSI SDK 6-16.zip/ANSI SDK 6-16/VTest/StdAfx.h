// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__E1F06F5B_CC81_4CCE_9CF0_10E32B13DCEC__INCLUDED_)
#define AFX_STDAFX_H__E1F06F5B_CC81_4CCE_9CF0_10E32B13DCEC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include "windows.h"
#include "winioctl.h"
//#include "stdio.h"

#include <stdio.h>
#include <tchar.h>
#include <string>
#include <algorithm>
using namespace std;






// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__E1F06F5B_CC81_4CCE_9CF0_10E32B13DCEC__INCLUDED_)
