# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 11:08:29 2020

@author: WangLabPC7
"""

import numpy as np
import matplotlib.pyplot as plt
from measurement import Measurement2D
#from lib.math import fit
from pulseseq.sequencer import *
from pulseseq.pulselib import *

def analysis(meas, data=None, fig=None):
    zs, fig = meas.get_ys_fig(data, fig)
    
    
    zs = zs.reshape(len(meas.ys),len(meas.xs))
    zs1 = zs[:,0:len(meas.xs)/2]
    zs2 = zs[:,len(meas.xs)/2:len(meas.xs)]
    zs_new = zs1 - zs2
    
    
#    zs_new = np.zeros(zs.size/2)
#    for i in range(zs.size/2):
##        zs_new[i] = zs[2*i+1]
#        
#        zs_new[i] = zs[2*i+]-zs[2*i]
    print(zs_new)
#    xs_new = np.zeros(len(meas.xs)/2)
#    for i in range(len(meas.xs)/2):
#        xs_new[i] = meas.xs[2*i]
    xs_new = meas.xs[:len(meas.xs)/2]    
#    zs_new = zs_new.reshape(len(meas.ys), len(xs_new))
    ys=meas.ys
    fig2 = plt.figure() 
    ax = plt.gca()

#    ax = fig.axes[0]
    plt.sca(ax)
    pc = ax.pcolormesh(xs_new, meas.ys, zs_new, cmap=plt.get_cmap('RdBu'))
    fig2.colorbar(pc)
#    ax = fig.axes[0]
#    plt.sca(ax)
#    pc = ax.pcolormesh(xs_new, meas.ys, zs_new, cmap=plt.get_cmap('RdBu'))
#    fig.colorbar(pc)

    ax.set_xlim(xs_new.min()), xs_new.max()
    ax.set_ylim(ys.min(), ys.max())
    ax.set_xlabel('times')
    ax.set_ylabel('rel_amp')
    fig.canvas.draw()

class Singlequbit_tuning_time_amp(Measurement2D):

#The purpose here is to sweep over time and detuning for the combined pulse without the pi pulse on the control qubit

    def __init__(self, gate_info1, gate_info2, times, rel_amps, amp=0.35, phase=0, rel_phase=1, sigma=5, 
                 update=False, seq=None, r_axis=0, fix_phase=True,
                 fix_period=None, repeat_pulse=1, postseq=None, selective=False, **kwargs):
        self.gate_info1 = gate_info1
        self.gate_info2 = gate_info2

        self.times = times
        self.rel_amps = rel_amps
#        self.xs2 = np.array([times,times]).transpose().flatten() / 1e3      # For plotting purposes        
#        self.xs2 = np.array([times,times])      # For plotting purposes

#        self.xs=times
        self.xs = np.array([times , times + times.max()]).flatten()      # For plotting purposes 
        self.ys=rel_amps
#        self.ys = np.array([rel_amps,rel_amps]).transpose().flatten() / 1e3      # For plotting purposes        
        
        self.amp = amp
        self.phase = phase
        self.rel_phase = rel_phase
        if seq is None:
            seq = Trigger(1000)
        self.seq = seq
        self.postseq = postseq
        self.fix_phase = fix_phase
        self.fix_period = fix_period
        self.repeat_pulse = repeat_pulse
        self.r_axis = r_axis
        self.selective = selective
        self.sigma = sigma
        
        XS, YS = np.meshgrid(self.xs, self.ys)
        self.two_axes = (-XS + 1j*YS)
        npoints = self.two_axes.size

#        XS2, YS = np.meshgrid(self.xs2, self.ys)
#
#        self.two_axes_double = (-XS2 + 1j*YS)
#
#        npoints_double = self.two_axes_double.size       



        super(Singlequbit_tuning_time_amp, self).__init__(npoints, infos=(gate_info1, gate_info2), **kwargs)
        self.data.create_dataset('two_axes', data=self.two_axes, dtype=np.complex)

    def generate(self):
        s = Sequence()
#        ampI = self.amp * np.cos(self.phase)
#        ampQ = self.amp * np.sin(self.phase)
#        ampIc = self.amp *self.rel_amps * np.cos(self.phase+self.rel_phase)
#        ampQc = self.amp *self.rel_amps * np.sin(self.phase+self.rel_phase)
        chs = self.gate_info1.sideband_channels1
        chs2 = self.gate_info1.sideband_channels2


        for rel_amp in self.rel_amps:
            for plen in self.times:

                
                '''Without pi pulse'''
                s.append(self.seq)    
    
#                if plen > 0:
                g=(Combined([
                        GaussSquare(int(plen), ampI, self.sigma, chan=chs[0]),
                        GaussSquare(int(plen), ampQ, self.sigma, chan=chs[1]),
                        GaussSquare(int(plen), ampIc, self.sigma, chan=chs2[0]),
                        GaussSquare(int(plen), ampQc, self.sigma, chan=chs2[1]),            
#                        Constant(int(plen), self.amp * np.cos(self.phase), chan=chs[0]),
#                        Constant(int(plen), self.amp * np.sin(self.phase), chan=chs[1]),
#                        Constant(int(plen), self.amp *rel_amp * np.cos(self.phase+self.rel_phase), chan=chs2[0]),
#                        Constant(int(plen), self.amp *rel_amp * np.sin(self.phase+self.rel_phase), chan=chs2[1]),              
                    ]))
                s.append(g)
#                s.append(g)
                if self.postseq:
                    s.append(self.postseq)
                s.append(Delay(10))
                s.append(Combined([
                    Constant(self.readout_info.pulse_len, 1, chan=self.readout_info.readout_chan),
                    Constant(self.readout_info.pulse_len, 1, chan=self.readout_info.acq_chan),
                ]))
                s.append(Delay(2000))

            for plen in self.times:
                '''With pi pulse'''
                s.append(self.seq)    
                s.append(self.gate_info2.rotate(np.pi,0))    
#                if plen > 0:
                g=(Combined([
                        GaussSquare(int(plen), ampI, self.sigma, chan=chs[0]),
                        GaussSquare(int(plen), ampQ, self.sigma, chan=chs[1]),
                        GaussSquare(int(plen), ampIc, self.sigma, chan=chs2[0]),
                        GaussSquare(int(plen), ampQc, self.sigma, chan=chs2[1]),            
#                        Constant(int(plen), self.amp * np.cos(self.phase), chan=chs[0]),
#                        Constant(int(plen), self.amp * np.sin(self.phase), chan=chs[1]),
#                        Constant(int(plen), self.amp *rel_amp * np.cos(self.phase+self.rel_phase), chan=chs2[0]),
#                        Constant(int(plen), self.amp *rel_amp * np.sin(self.phase+self.rel_phase), chan=chs2[1]),              
                    ]))

                s.append(g)
                s.append(self.gate_info2.rotate(np.pi,0))    
                if self.postseq:
                    s.append(self.postseq)
                s.append(Delay(10))
                s.append(Combined([
                    Constant(self.readout_info.pulse_len, 1, chan=self.readout_info.readout_chan),
                    Constant(self.readout_info.pulse_len, 1, chan=self.readout_info.acq_chan),
                ]))
                s.append(Delay(2000))


            
            
        s = self.get_sequencer(s)
        seqs = s.render()
        return seqs


    def get_ys(self, data=None):
        ys = super(Singlequbit_tuning_time_amp, self).get_ys(data)
        return ys

    def analyze(self, data=None, fig=None):
        self.fit_params = analysis(self, data=data, fig=fig)


